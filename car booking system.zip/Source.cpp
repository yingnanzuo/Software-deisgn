#include <string>
#include <iostream>
#include<vector>
#include<algorithm>
#include<fstream>
#include<iomanip>

using namespace std;
class Car
{
private:
	string brand;
	string vehicleID;
	int status = 0;
	string brrow = "None";
public:
	Car() {}
	Car(string BD, string vID,int s)
	{
		brand = BD;
		vehicleID = vID;
		status = s;
	}
	int getstatus() { return status; }
	void setstatus(int s) { status = s; }
	void setbrrow(string b) { brrow = b; }
	string getbrrow() { return brrow; }
	string getbrand() { return brand; }
	string getvehicleID() { return vehicleID; }
	void set(string B, string V)
	{
		brand = B;
		vehicleID = V;
	}
	void print()
	{
		cout << "The brand of the car is: " << getbrand() << endl
			<< "The vehicleID of the car is: " << getvehicleID() << endl
			<< "The status of the car is: ";
		if (getstatus() == 0)
			cout << "avilable" << endl;
		else
			cout << "unavilable" << endl;
		cout << "Name of the owner: " << getbrrow() << endl;
	}
};
class Employee
{
private:
	string dateCheckout;
	string driverName;
	int recordID;
	double mileage;
public:
	Employee() {}
	Employee(string date, string Name, int ID, double mil)
	{
		dateCheckout = date;
		driverName = Name;
		recordID = ID;
		mileage = mil;

	}
	string getDate() { return dateCheckout; }
	string getName() { return driverName; }
	int getID() { return recordID; }
	double getMileage() { return mileage; }
	void setdata(string date, string Name, int ID, double mil) {
		dateCheckout = date;
		driverName = Name;
		recordID = ID;
		mileage = mil;
	}
	//Employee * ptr;
	virtual void print() {
		 cout << "date checkout: " << getDate() << endl << "driver name: " << getName() << endl
			<< "record ID: " << getID() << endl << "Mileage: " << getMileage() << endl;
	}
};

class Company_use : public Employee
{
private:
	string purpose;
	double fuelCost;

public:
	Company_use() {}
	Company_use(string date, string Name, int ID, double mil, Car& c, string purpose, double fuelCost);
	void setPurpose(string purpose) { this->purpose = purpose; }
	void setFuelCost(double fuelCost) { this->fuelCost = fuelCost; }
	string getPurpose() { return purpose; }
	double getFuelCost() { return fuelCost; }
	virtual void print() { Employee::print(); cout << "purpose: " << getPurpose() << "fuel cost: " << getFuelCost() << endl; }

};
Company_use::Company_use(string date, string Name, int ID, double mil, Car& c, string purpose, double fuelCost):Employee(date,Name,ID,mil)
{
	this->purpose = purpose;
	this->fuelCost = fuelCost;
}

class Personal_use : public Employee
{
private:
	string insurance;
public:
	Personal_use() {}
	Personal_use(string date, string driverName, int recordID, double mileage, Car& c, string insurance);
	void setInsurance(string insurance) { this->insurance = insurance; }
	string getInsurance() { return insurance; }
	virtual void print() { Employee::print(); cout << "Insurance: " << getInsurance() << endl; }
};

Personal_use::Personal_use(string date, string driverName, int recordID, double mileage, Car& c, string insurance) :Employee(date, driverName, recordID, mileage)
{
	this->insurance = insurance;
}
//Yeting Part

class Carry_passengers : public Employee
{
private:
	vector<string>name;

public:

	Carry_passengers() {}
	Carry_passengers(string date, string driverName, int recordID, double mileage, Car& c, vector<string>personName);
	vector<string>GetCopyOfVector() { return name; } //page 28

	virtual void print()
	{
		cout << "There are " << name.size() << " passengers in the car." << endl;
		cout << "The name of the passengers list is " << endl;
		for (int i = 0; i < name.size(); i++)
		{
			cout << name[i] << endl;

		}

	}
};

Carry_passengers::Carry_passengers(string date, string driverName, int recordID, double mileage, Car& c, vector<string>personName) : Employee(date, driverName, recordID, mileage)
{
	for(int i=0;i<personName.size();i++)
	    name.push_back(personName[i]);
}
class Carry_Cargo : public Employee
{
private:
	string inventory;

public:
	Carry_Cargo() {}
	Carry_Cargo(string date, string driverName, int recordID, double mileage, Car& c, string inventory);
	string getInventory() { return inventory; }
	virtual void print()
	{
		Employee::print();
		cout << "The inventory of this cargo is " << inventory << endl;
	}
};


Carry_Cargo::Carry_Cargo(string date, string driverName, int recordID, double mileage, Car& c, string inventory) : Employee(date, driverName, recordID, mileage)
{
	this->inventory = inventory;
}
void print_car(vector<Car>& a) {
	for (int i = 0; i < a.size(); i++) {
		cout << i + 1 << '.';
		a[i].print();
	}
}
void print_Emp(vector<Employee> &a) {//a function print a list of employee.
	int size;
	size = a.size();
	for (int i = 0; i < size; i++) {
		a[i].print();
	}
}
void FourUse(Employee&b, vector<Car>& a) {//into the mini menus.
	cout << "* 1.company use                *" << endl;
	cout << "* 2.personal use               *" << endl;
	cout << "* 3.Carry passenger use        *" << endl;
	cout << "* 4.Carry cargo use            *" << endl;

	int i,d;
	cin >> i;
	vector<string>name;
	string e, f;
	double c; 
	Employee *ptr;
	bool find = false;
	switch (i) {
	case 1:
		cout << "what purpose? ";
		cin >> e;
		cout << "How much fuel cost? " << endl;
		cin >> c;
		while (!find) {
			cout << "Which car do you want to use, enter the plate: " << endl;
			cin >> f;
			for (int j =0; j < a.size(); j++) {//check the plate
				if (f == a[j].getvehicleID() && a[j].getstatus() == 0) {
					a[j].setstatus(1);
					a[j].setbrrow(b.getName());
					find = true;
					break;
				}
				if (f == a[j].getvehicleID() && a[j].getstatus() != 0) {
					cout << "car unable to borrow.please re-choose a car" << endl;
					break;
				}
				if (j == a.size() - 1) {
					cout << "wrong car. please re-choose a car" << endl;
					break;
				}

			}
		}
		ptr = new Company_use(b.getDate(), b.getName(), b.getID(), b.getMileage(), a[i], e, c);//into to the company use class.
		//b.car->startBorrow(a);
		ptr->print();
		delete ptr;
		break;
	case 2:
		cout << "Input insurance: ";
		cin >> e;
		while (!find) {
			cout << "Which car do you want to use, enter the plate: " << endl;
			cin >> f;
			for (int j = 0; j < a.size(); j++) {//check the plate
				if (f == a[j].getvehicleID() && a[j].getstatus() == 0) {
					a[j].setstatus(1);
					a[j].setbrrow(b.getName());

					find = true;
					break;
				}
				if (f == a[j].getvehicleID() && a[j].getstatus() != 0) {
					cout << "car unable to borrow.please re-choose a car" << endl;
					break;
				}
				if (j == a.size() - 1) {
					cout << "wrong car. please re-choose a car" << endl;
					break;
				}

			}
		}
		ptr = new Personal_use(b.getDate(), b.getName(), b.getID(), b.getMileage(), a[i], e);//into the personal use class.
		ptr->print();
		delete ptr;
		break;
	case 3:
		cout << "Input the number of your passengers: ";
		cin >> d;
		for (int i = 0; i < d; i++) {
			cout << "Input your passengers' name: ";
			cin >> e;
			name.push_back(e);
		}
		while (!find) {
			cout << "Which car do you want to use, enter the plate: " << endl;
			cin >> f;
			for (int j = 0; j < a.size(); j++) {//check the plate
				if (f == a[j].getvehicleID() && a[j].getstatus() == 0) {
					a[j].setstatus(1);
					a[j].setbrrow(b.getName());

					find = true;
					break;
				}
				if (f == a[j].getvehicleID() && a[j].getstatus() != 0) {
					cout << "car unable to borrow.please re-choose a car" << endl;
					break;
				}
				if (j == a.size() - 1) {
					cout << "wrong car. please re-choose a car" << endl;
					break;
				}

			}
		}
		ptr = new Carry_passengers(b.getDate(), b.getName(), b.getID(), b.getMileage(), a[i], name);//into the personal use class.
		ptr->print();
			delete ptr;
			break;
	case 4:
		cout << "Input inventory: ";
		cin >> e;

		while (!find) {
			cout << "Which car do you want to use, enter the plate: " << endl;
			cin >> f;
			for (int j = 0; j < a.size(); j++) {//check the plate
				if (f == a[j].getvehicleID() && a[j].getstatus() == 0) {
					a[j].setstatus(1);
					a[j].setbrrow(b.getName());

					find = true;
					break;
				}
				if (f == a[j].getvehicleID() && a[j].getstatus() != 0) {
					cout << "car unable to borrow.please re-choose a car" << endl;
					break;
				}
				if (j == a.size() - 1) {
					cout << "wrong car. please re-choose a car" << endl;
					break;
				}

			}
		}
		ptr = new Carry_Cargo(b.getDate(), b.getName(), b.getID(), b.getMileage(), a[i], e);//into the personal use class.
		ptr->print();
			delete ptr;
			break;

	}
		}

	bool menu(Employee&b, vector<Car> &a) {//menus
		int j;
		bool exit = false;
		cout << "**************menu**************" << endl;
		cout << "* 1.look current cars status   *" << endl;
		cout << "* 2.Start borrow a car         *" << endl;
		cout << "* 3.exit                      *" << endl;
		cout << "********************************" << endl;
		cin >> j;
		switch (j) {
		case 1: print_car(a);
			break;
		case 2: FourUse(b, a);
			break;
		case 3: exit = true;
			break;
		}
		return exit;
	}

int main() {
	ifstream fin,infile;
	ofstream fout, outfile;
	vector<Car>A;
	vector<Employee>B;

	Car a;
	Employee b;
	string name, date, plate,brand;
	char type;
	int ID,status;
	double mil;
	int EmpNo;
	fin.open("input.txt");
	//fin >> brand >> plate >> status;

	while (!fin.eof()) {//reading input.txt
		fin >> brand >> plate >> status;
		a.set(brand, plate);
		a.setstatus(status);
		A.push_back(a);//push into the vector
		

	}
	print_car(A);

	infile.open("employee.txt");//reading Vehicle.txt
	while (!infile.eof()) {
		infile >> ID >> name >> date >> mil;
		b.setdata(date, name, ID, mil);

		B.push_back(b);//push into the vector
	}
	//print_Emp(B);
	fin.close();
	infile.close();
	cout << "please enter your ID: ";
	cin >> ID;
	bool access = false;
	for (int i = 0; i < B.size(); i++) {//check the ID
		if (ID == B[i].getID()) {
			cout << "login sucess" << endl;
			cout << "wellcome back ";
			B[i].print();
			EmpNo = i;
			access = true;
			break;
		}
		else {
			access = false;
		}
	}
	if (access == false) {
		cout << "fail to enter." << endl;
		return 0;
	}
	while (!menu(B[EmpNo], A)) {//menus start.
		menu(B[EmpNo], A);
	}

	fout.open("input.txt");//over write the previous file, and storage new.
	for (int i = 0; i < A.size(); i++) {
		fout << left << setw(10) << A[i].getbrand() << " " << setw(15) << A[i].getvehicleID() << ' ' << setw(10) << A[i].getstatus() << endl;
	}

	return 0;
}
